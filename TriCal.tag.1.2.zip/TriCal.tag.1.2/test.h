#ifndef __TEST_H
#define __TEST_H

double pi_deviat(double pi);
double sin_deviat(double angle, int n, double pi);
double cos_deviat(double angle, int n, double pi);
double tan_deviat(double angle, int n, double pi);
double arcs_deviat(double angle, int n, double accu, double pi);
double arcc_deviat(double angle, int n, double accu, double pi);
double arct_deviat(double angle, int n, double accu, double pi);

#endif 
